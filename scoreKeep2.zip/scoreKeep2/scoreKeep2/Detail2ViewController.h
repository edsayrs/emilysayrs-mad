//
//  Detail2ViewController.h
//  scoreKeep2
//
//  Created by Emily Sayrs on 10/31/13.
//  Copyright (c) 2013 Emily Sayrs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Detail2ViewController : UITableViewController

@end
